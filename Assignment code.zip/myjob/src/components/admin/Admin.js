import PostAJob from '../Job/PostAJob'

const Admin = () => {
  return (
    <div>
      <PostAJob />
    </div>
  )
}

export default Admin
